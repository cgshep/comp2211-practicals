from secrets import token_bytes
from Crypto.Cipher import ChaCha20_Poly1305

key = token_bytes(32)
nonce = token_bytes(12)
message = b"Room 204 is booked for 10:00."

sender = ChaCha20_Poly1305.new(key=key, nonce=nonce)
ciphertext, tag = sender.encrypt_and_digest(message)

received_ciphertext = ciphertext
received_tag = tag
receiver = ChaCha20_Poly1305.new(key=key, nonce=nonce)
try:
    recovered = receiver.decrypt_and_verify(received_ciphertext, received_tag)
except ValueError:
    print("Rejected: authentication failed")
else:
    print("Accepted:", recovered.decode("utf-8"))
