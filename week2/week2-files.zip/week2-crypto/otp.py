from secrets import token_bytes
from byte_tools import xor_bytes

message = input("Message: ").encode("utf-8")
pad = token_bytes(len(message))
ciphertext = xor_bytes(message, pad)
recovered = xor_bytes(ciphertext, pad)

print("Message bytes:", len(message))
print("Pad bytes:", len(pad))
print("Ciphertext (hex):", ciphertext.hex())
print("Recovered:", recovered.decode("utf-8"))
print("Same bytes:", recovered == message)
