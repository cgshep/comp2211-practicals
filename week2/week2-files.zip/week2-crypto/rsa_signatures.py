from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Signature import pss

# The signer keeps the private key; the receiver only needs the public key.
private_key = RSA.generate(3072)
public_key = private_key.public_key()
message = b"Room 204 is booked for 10:00."

signature = pss.new(private_key).sign(SHA256.new(message))
print("Signature bytes:", len(signature))

# Change this received copy for the alteration experiment.
received_message = message
try:
    pss.new(public_key).verify(SHA256.new(received_message), signature)
except ValueError:
    print("Rejected: invalid signature")
else:
    print("Accepted: valid signature")
