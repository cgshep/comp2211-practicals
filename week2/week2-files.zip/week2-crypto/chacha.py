from secrets import token_bytes
from Crypto.Cipher import ChaCha20

key = token_bytes(32)
nonce = token_bytes(12)
message = b"Room 204 is booked for 10:00."

sender = ChaCha20.new(key=key, nonce=nonce)
ciphertext = sender.encrypt(message)
print("Nonce (hex):", nonce.hex())
print("Ciphertext (hex):", ciphertext.hex())
print("Lengths:", len(message), len(ciphertext))

# Add your decryption and comparisons below.
