def xor_bytes(left, right):
    if len(left) != len(right):
        raise ValueError("The byte sequences must have equal lengths")

    # Replace this line with your XOR loop and return the result as bytes.
    raise NotImplementedError("Complete xor_bytes first")
