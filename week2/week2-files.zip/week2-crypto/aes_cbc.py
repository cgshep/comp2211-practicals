from pathlib import Path
from secrets import token_bytes
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

key = token_bytes(16)
iv = token_bytes(16)
message = Path("data/records.bin").read_bytes()
ciphertext = AES.new(key, AES.MODE_CBC, iv=iv).encrypt(message)

for offset in range(0, len(ciphertext), 16):
    print(offset // 16, ciphertext[offset:offset + 16].hex())

receiver = AES.new(key, AES.MODE_CBC, iv=iv)
recovered = receiver.decrypt(ciphertext)
print("Same bytes:", recovered == message)

# Optional: add the file experiment from the sheet.
